package paintproject;

import static org.junit.jupiter.api.Assertions.*;
import org.testfx.framework;

class PaintProjectTest extends ApplicationClass {

}