/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintproject;

import java.io.File;
import java.util.Stack;
import javafx.scene.Group;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Toggle;
import javafx.scene.image.WritableImage;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.testfx.api.FxToolkit;
import org.testfx.framework.junit.ApplicationTest;


/**
 *
 * @author micha
 */
public class CanvasTabTest extends ApplicationTest {
    
    public CanvasTabTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getFile method, of class CanvasTab.
     */
    @Test
    public void testGetFile() {
        System.out.println("setFile");
        File expResult = null;
        CanvasTab instance =  new CanvasTab("Test");
        File result  = instance.getFile();
        assertEquals(expResult, result);
    }

    /**
     * Test of getSaved method, of class CanvasTab.
     */
    @Test
    public void testGetSaved() {
        System.out.println("getSaved");
        CanvasTab instance = new CanvasTab("Test");
        boolean expResult = true;
        boolean result = instance.getSaved();
        assertEquals(expResult, result);
    }
    /**
     * Test of resetCountdown method, of class CanvasTab.
     */
    @Test
    public void testGetCountdown() {
        System.out.println("resetCountdown");
        CanvasTab instance = new CanvasTab("Test");
        long expResult = 120;
        long result = instance.getCountdown();
        assertEquals(expResult, result);
    }
}
