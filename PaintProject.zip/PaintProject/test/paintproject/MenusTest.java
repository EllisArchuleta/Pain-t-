/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintproject;

import java.io.File;
import java.util.Stack;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author micha
 */
public class MenusTest {
    
    public MenusTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of openFile method, of class Menus.
     */
    @Test
    public void testOpenFile() throws Exception {
        System.out.println("openFile");
        Stage primaryStage = null;
        CanvasTab tab = null;
        File expResult = null;
        File result = Menus.openFile(primaryStage, tab);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of saveFile method, of class Menus.
     */
    @Test
    public void testSaveFile() throws Exception {
        System.out.println("saveFile");
        Stage primaryStage = null;
        CanvasTab tab = null;
        Menus.saveFile(primaryStage, tab);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of saveAsFile method, of class Menus.
     */
    @Test
    public void testSaveAsFile() throws Exception {
        System.out.println("saveAsFile");
        Stage primaryStage = null;
        Canvas canvas = null;
        Menus.saveAsFile(primaryStage, canvas);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Exit method, of class Menus.
     */
    @Test
    public void testExit() throws Exception {
        System.out.println("Exit");
        Stage primaryStage = null;
        CanvasTab tab = null;
        Menus.Exit(primaryStage, tab);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of configureFileChooser method, of class Menus.
     */
    @Test
    public void testConfigureFileChooser() {
        System.out.println("configureFileChooser");
        FileChooser fileChooser = null;
        Menus.configureFileChooser(fileChooser);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of resize method, of class Menus.
     */
    @Test
    public void testResize() {
        System.out.println("resize");
        Canvas canvas = null;
        GraphicsContext context = null;
        Stack<WritableImage> undoStack = null;
        Menus.resize(canvas, context, undoStack);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of menuAbout method, of class Menus.
     */
    @Test
    public void testMenuAbout() throws Exception {
        System.out.println("menuAbout");
        Menus.menuAbout();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
