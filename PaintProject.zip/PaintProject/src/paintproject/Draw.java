/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintproject;

import java.util.Arrays;
import java.util.Stack;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Rectangle2D;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseButton;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

/**
 * Methods involving drawing and the making or undoing of changes to the Canvas
 * @author Ellis Archuleta
 */
public abstract class Draw {

    static DragBox dragBox = null;
    static Rectangle rect = new Rectangle(0, 0, 0, 0);
    /**
     * Draws a freehand line as the user clicks and drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     */
    public static void freeHand(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack) {
        Line line = new Line();

        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.beginPath();
                context.moveTo(event.getX(), event.getY());
                context.stroke();
                System.out.println("Go");
            }
        });

        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.lineTo(event.getX(), event.getY());
                context.setStroke(colorPicker.getValue());
                context.stroke();
            }
        });

        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }
            }

        });
    }
    /**
     * Erases as the user clicks and drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param undoStack Stack of changes made to the Canvas
     */
    public static void eraserDraw(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack) {
        context.setStroke(Color.WHITE);
        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.beginPath();
                context.moveTo(event.getX(), event.getY());
                context.stroke();
            }
        });

        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.lineTo(event.getX(), event.getY());
                context.setStroke(Color.WHITE);
                context.stroke();
            }
        });

        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }

            }
        });
    }
    /**
     * Draws a straight line from the point where the user clicks to the point
     * where the user releases the mouse, displaying a temporary line as the user
     * drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     */
    public static void lineDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack) {
        Line line = new Line();
        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.moveTo(event.getX(), event.getY());
                line.setStartX(event.getX());
                line.setStartY(event.getY());
                line.setEndX(event.getX());
                line.setEndY(event.getY());
            }
        });
        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                WritableImage wImage = undoStack.peek();
                context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                line.setEndX(event.getX());
                line.setEndY(event.getY());
                context.strokeLine(line.getStartX(), line.getStartY(), line.getEndX(), line.getEndY());
            }
        });
        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }

            }
        });
    }
    /**
     * Draws a rectangle with one corner where the user clicks and the opposite 
     * corner at the point where the user releases the mouse, 
     * displaying a temporary rectangle as the user drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     */
    public static void rectangleDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack) {
        rect = new Rectangle(0, 0, 0, 0);
        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.beginPath();
                context.moveTo(event.getX(), event.getY());
                rect.setX(event.getX());
                rect.setY(event.getY());
            }
        });
        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                WritableImage wImage = undoStack.peek();
                context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                double width = Math.abs(event.getX() - rect.getX());
                double height = Math.abs(event.getY() - rect.getY());
                context.fillRect(Math.min(event.getX(), rect.getX()), Math.min(event.getY(), rect.getY()), width, height);
            }
        });
        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }

            }
        });
    }
    /**
     * Draws a square within the bounds of a user-specified rectangle with one corner where the user clicks and the opposite 
     * corner at the point where the user releases the mouse, 
     * displaying a temporary square as the user drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     */
    public static void squareDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack) {
        rect = new Rectangle(0, 0, 0, 0);
        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.beginPath();
                context.moveTo(event.getX(), event.getY());
                rect.setX(event.getX());
                rect.setY(event.getY());
            }
        });
        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                WritableImage wImage = undoStack.peek();
                context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                double hypo = ((event.getX() - rect.getX()) * (event.getX() - rect.getX()) + (event.getY() - rect.getY()) * (event.getY() - rect.getY()));
                double length = Math.sqrt(hypo / 2);
                context.fillRect(Math.min(event.getX(), rect.getX()), Math.min(event.getY(), rect.getY()), length, length);
            }
        });
        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }

            }
        });
    }
    /**
     * Draws an ellipse within the bounds of a user-specified rectangle with one corner where the user clicks and the opposite 
     * corner at the point where the user releases the mouse, 
     * displaying a temporary ellipse as the user drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     */
    public static void ellipseDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack) {
        Ellipse ellipse = new Ellipse();
        Ellipse tempEllipse = new Ellipse();
        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.beginPath();
                context.moveTo(event.getX(), event.getY());
                ellipse.setCenterX(event.getX());
                ellipse.setCenterY(event.getY());
                tempEllipse.setCenterX(ellipse.getCenterX());
                tempEllipse.setCenterY(ellipse.getCenterY());
            }
        });
        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                WritableImage wImage = undoStack.peek();
                context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                double left = Math.min(event.getX(), ellipse.getCenterX());
                double top = Math.min(event.getY(), ellipse.getCenterY());
                double width = Math.abs(ellipse.getCenterX() - event.getX());
                double height = Math.abs(ellipse.getCenterY() - event.getY());
                context.fillOval(left, top, width, height);
            }
        });
        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }

            }
        });
    }
    /**
     * Draws a circle within the bounds of a user-specified rectangle with one corner where the user clicks and the opposite 
     * corner at the point where the user releases the mouse, 
     * displaying a temporary circle as the user drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     */
    public static void circleDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack) {
        Ellipse ellipse = new Ellipse();
        Ellipse tempEllipse = new Ellipse();
        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.beginPath();
                context.moveTo(event.getX(), event.getY());
                ellipse.setCenterX(event.getX());
                ellipse.setCenterY(event.getY());
                tempEllipse.setCenterX(ellipse.getCenterX());
                tempEllipse.setCenterY(ellipse.getCenterY());
            }
        });
        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                WritableImage wImage = undoStack.peek();
                context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                double left = Math.min(event.getX(), ellipse.getCenterX());
                double top = Math.min(event.getY(), ellipse.getCenterY());
                double width = Math.abs(ellipse.getCenterX() - event.getX());
                double height = Math.abs(ellipse.getCenterY() - event.getY());
                double diameter = Math.sqrt(width * width + height * height);
                System.out.println("width: " + width);
                System.out.println("height: " + height);
                System.out.println("diameter: " + diameter);
                context.fillOval(left, top, diameter, diameter);
            }
        });
        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }

            }
        });
    }
    /**
     * Draws a rhombus within the bounds of a user-specified rectangle with one corner where the user clicks and the opposite 
     * corner at the point where the user releases the mouse, 
     * displaying a temporary rhombus as the user drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     */
    public static void rhombusDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack) {
        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.beginPath();
                context.moveTo(event.getX(), event.getY());
                rect.setX(event.getX());
                rect.setY(event.getY());
            }
        });
        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                WritableImage wImage = undoStack.peek();
                context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                double left = Math.min(event.getX(), rect.getX());
                double top = Math.min(event.getY(), rect.getY());
                double width = Math.abs(event.getX() - rect.getX());
                double height = Math.abs(event.getY() - rect.getY());
                double[] xPoints = {left + width * 0.25, left + width, left + width * 0.75, left};
                double[] yPoints = {top, top, top + height, top + height};
                if (rect.getX() > event.getX()) {
                    for (int i = 0; i < xPoints.length / 2; i++) {
                        double tempX = xPoints[i];
                        xPoints[i] = xPoints[xPoints.length - (i + 1)];
                        xPoints[xPoints.length - (i + 1)] = tempX;
                    }
                }
                if (rect.getY() > event.getY()) {
                    for (int i = 0; i < xPoints.length / 2; i++) {
                        double tempY = yPoints[i];
                        yPoints[i] = yPoints[yPoints.length - (i + 1)];
                        yPoints[yPoints.length - (i + 1)] = tempY;
                    }
                }
                context.fillPolygon(xPoints, yPoints, xPoints.length);
            }
        });
        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }

            }
        });
    }
    /**
     * Draws a polygon with the specified number of sides within the bounds of a user-specified rectangle with one corner where the user clicks and the opposite 
     * corner at the point where the user releases the mouse, 
     * displaying a temporary polygon as the user drags the mouse
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     * @param nSides number of sides of the polygon, selected when the tool is chosen
     */
    public static void polygonDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack, double nSides) {
        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.beginPath();
                rect.setX(event.getX());
                rect.setY(event.getY());
                System.out.println(nSides);
                System.out.println(Math.tan(Math.PI / nSides));
            }
        });
        canvas.setOnMouseDragged((event) -> {
            double left = Math.min(event.getX(), rect.getX());
            double top = Math.min(event.getY(), rect.getY());
            double width = Math.abs(event.getX() - rect.getX());
            double height = Math.abs(event.getY() - rect.getY());
            double incAngle = 2 * Math.PI / nSides;
            double[] xPoints = new double[(int) nSides];
            double[] yPoints = new double[(int) nSides];
            double startAngle = -Math.PI / nSides;
            System.out.println("incAngle: " + incAngle);

            yPoints[0] = top;
            xPoints[0] = left + 0.5 * width/*(1-Math.tan(Math.PI/nSides))*/;
            System.out.println("odd");

            for (int i = 1; i < nSides; i++) {
                xPoints[i] = xPoints[i - 1] + (width * Math.sin(Math.PI / nSides)) * Math.cos(startAngle + (i) * incAngle);
                yPoints[i] = yPoints[i - 1] + (height * Math.sin(Math.PI / nSides)) * Math.sin(startAngle + (i) * incAngle);
                System.out.println((startAngle - (i - 1) * incAngle));
                System.out.println("cos " + i + ": " + Math.cos(startAngle - (i - 1) * incAngle));
                System.out.println("sin " + i + ": " + Math.sin(startAngle - (i - 1) * incAngle));
                //System.out.println("xPoint:"+xPoints[i]);
                //System.out.println("yPoint"+yPoints[i]);
            }
            System.out.println("xPoints:" + Arrays.toString(xPoints));
            System.out.println("yPoints" + Arrays.toString(yPoints));
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            WritableImage wImage = undoStack.peek();
            context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
            context.fillPolygon(xPoints, yPoints, (int) nSides);
        });
        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                context.closePath();
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                undoStack.push(wImage);
                if (undoStack.peek() != null) {
                    System.out.println("Pushed");
                }
                double left = Math.min(event.getX(), rect.getX());
                double top = Math.min(event.getY(), rect.getY());
                double width = Math.abs(event.getX() - rect.getX());
                double height = Math.abs(event.getY() - rect.getY());
                context.setStroke(Color.LIGHTGREY);
                context.setLineWidth(1); //small grey line to denote the DragBox
                context.strokeRect(left, top, width, height);
                

            }
        });

    }
    /**
     * 
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param widthSlider Slider representing the desired width of a line
     * @param opacitySlider Slider representing the desired opacity of a color
     * @param colorPicker the program's ColorPicker
     * @param undoStack Stack of changes made to the Canvas
     * @param textString the String to be written on the Canvas, given at tool select
     */
    public static void textDraw(Canvas canvas, GraphicsContext context, Slider widthSlider, Slider opacitySlider, ColorPicker colorPicker, Stack<WritableImage> undoStack, String textString) {
        canvas.setOnMousePressed((event) -> {
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            WritableImage wImage = undoStack.peek();
            context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
            Color fillColor = colorPicker.getValue().deriveColor(1, 1, 1, opacitySlider.getValue());
            context.setFill(fillColor);
            context.setStroke(fillColor);
            context.setFont(new Font(5*widthSlider.getValue()));
            context.setTextAlign(TextAlignment.CENTER);
            context.fillText(textString, event.getX(), event.getY());
            context.closePath();
            wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
            canvas.snapshot(null, wImage);
            undoStack.push(wImage);
        });
        canvas.setOnMouseDragged((event) -> {
        });
        canvas.setOnMouseReleased((event) -> {
        });

    }
    /**
     * Creates a DragBox with the width and height of a rectangle specified by the user,
     * containing the image within that rectangle, which can then be moved around the canvas
     * leaving a void behind
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param undoStack Stack of changes made to the Canvas
     * @return the created DragBox to the user specification
     * @see DragBox
     */
    public static DragBox selectDraw(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack) {

        canvas.setOnMousePressed((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                if (dragBox != null) {
                    if (dragBox.getBounds().contains(event.getX(), event.getY())) {
                        System.out.println("Beginning drag");
                        dragBox.drag(canvas, context, undoStack, event.getX(), event.getY());
                    } else {
                        System.out.println("out of box");
                        context.beginPath();
                        context.moveTo(event.getX(), event.getY());
                        context.setStroke(Color.LIGHTGREY);
                        context.setLineWidth(1); //small black line to denote the DragBox
                        rect.setX(event.getX());
                        rect.setY(event.getY());
                    }
                } else {
                    context.beginPath();
                    context.moveTo(event.getX(), event.getY());
                    context.setStroke(Color.LIGHTGREY);
                    context.setLineWidth(1); //small black line to denote the DragBox
                    rect.setX(event.getX());
                    rect.setY(event.getY());
                }
            }
        });
        canvas.setOnMouseDragged((event) -> {
            if (event.isPrimaryButtonDown()) {
                context.setStroke(Color.LIGHTGREY);
                context.setLineWidth(1); //small black line to denote the DragBox
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                WritableImage wImage = undoStack.peek();
                context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                double width = Math.abs(event.getX() - rect.getX());
                double height = Math.abs(event.getY() - rect.getY());
                System.out.println(rect.getX() + ", " + rect.getY());
                context.strokeRect(Math.min(event.getX(), rect.getX()), Math.min(event.getY(), rect.getY()), width, height);

            }
        });
        canvas.setOnMouseReleased((event) -> {
            if (event.getButton().equals(MouseButton.PRIMARY)) {
                double left = Math.min(event.getX(), rect.getX());
                double top = Math.min(event.getY(), rect.getY());
                double width = Math.abs(event.getX() - rect.getX());
                double height = Math.abs(event.getY() - rect.getY());
                if (width > 0 && height > 0) {
                    WritableImage pushImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                    WritableImage dragImage = new WritableImage((int) Math.abs(width), (int) Math.abs(height));
                    SnapshotParameters param = new SnapshotParameters();
                    param.setViewport(new Rectangle2D(left, top, width, height));
                    System.out.println("left: " + left);
                    System.out.println("top: " + top);
                    System.out.println("width: " + width);
                    System.out.println("height: " + height);
                    System.out.println("transform: " + param.getViewport().toString());
                    context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                    WritableImage wImage = undoStack.peek();
                    context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                    canvas.snapshot(param, dragImage);
                    context.clearRect(left + 1, top + 1, width - 1, height - 1);
                    canvas.snapshot(null, pushImage);
                    context.strokeRect(left, top, width, height);
                    context.drawImage(dragImage, left, top);
                    dragBox = new DragBox(dragImage, pushImage, left, top, width, height);
                }

            }
        });
        return dragBox;
    }
    /**
     * Changes the current color of the ColorPicker to that of a spot on the canvas as specified by the user
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param colorPicker the program's ColorPicker
     */
    public static void colorGrabber(Canvas canvas, GraphicsContext context, ColorPicker colorPicker) {
        canvas.setOnMousePressed((event) -> {
            if (!event.isSecondaryButtonDown() && event.isPrimaryButtonDown()) {
                System.out.println("Grabbing a Color");
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                PixelReader pixelReader = wImage.getPixelReader();
                colorPicker.setValue(pixelReader.getColor((int) event.getX(), (int) event.getY()));
            }
        });
        canvas.setOnMouseDragged((event) -> {
        });
        canvas.setOnMouseReleased((event) -> {
        });
    }
    /**
     * Undoes the last change made to the Canvas, moving it from the undoStack to the redoStack
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param undoStack Stack of changes made to the Canvas
     * @param redoStack Stack of changes that have been undone
     */
    public static void undo(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack, Stack<WritableImage> redoStack) {
        if (undoStack.size() > 1)//First make sure we're not clearing the pre-loaded image
        {
            //Clear out the canvas 
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            //Pop the undoStack into the redoStack and draw the next image
            redoStack.push(undoStack.pop());
            WritableImage wImage = undoStack.peek();
            canvas.setWidth(wImage.getWidth());
            canvas.setHeight(wImage.getHeight());
            context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
        }
        dragBox = null;
    }
    /**
     * Reverts the undoing of the most recently undone change, moving it from the redoStack back to the undoStack
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param undoStack Stack of changes made to the Canvas
     * @param redoStack Stack of changes that have been undone
     */
    public static void redo(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack, Stack<WritableImage> redoStack) {
        if (redoStack.size() > 0)//First make sure we're not clearing the pre-loaded image
        {
            //Clear out the canvas
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            //Pop the redoStack into the undoStack and draw the next image
            WritableImage wImage = redoStack.peek();
            undoStack.push(redoStack.pop());
            canvas.setWidth(wImage.getWidth());
            canvas.setHeight(wImage.getHeight());
            //And drawing the image on to it
            context.drawImage(wImage, 0, 0, canvas.getWidth(), canvas.getHeight());
        }
        dragBox = null;
    }
    /**
     * Zooms into the canvas image
     *
     * @param canvas the current Canvas
     */
    public static void zoomIn(Canvas canvas) {
        canvas.setScaleX(canvas.getScaleX() * 2);
        canvas.setScaleY(canvas.getScaleY() * 2);
    }
    /**
     * Zooms out of the canvas image
     *
     * @param canvas the current Canvas
     */
    public static void zoomOut(Canvas canvas) {
        if (canvas.getScaleX() > 0 && canvas.getScaleY() > 0) {
            canvas.setScaleX(canvas.getScaleX() / 2);
            canvas.setScaleY(canvas.getScaleY() / 2);
        }
    }
    /**
     * Resizes the canvas, and the image drawn onto it, to the specified width and height
     * @param canvas the current Canvas
     * @param context GraphicsContext of the Canvas
     * @param undoStack Stack of changes made to the Canvas
     * @param width User specified width of the Canvas
     * @param height User specified height of the Canvas
     */
    public static void resize(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack, double width, double height) {
        double newScaleX = width / canvas.getWidth();
        double newScaleY = height / canvas.getHeight();
        canvas.setScaleX(newScaleX);
        canvas.setScaleY(newScaleY);
        WritableImage wImage = new WritableImage((int) width, (int) height);
        canvas.snapshot(null, wImage);
        context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        canvas.setWidth(width);
        canvas.setHeight(height);
        context.drawImage(wImage, 0, 0);
        canvas.setScaleX(1);
        canvas.setScaleY(1);
        undoStack.push(wImage);
    }
    /**
     * A user-specified rectangle section of the Canvas used to implement a click-and-drag function 
     */
    public static class DragBox {

        WritableImage dragImage, pushImage; //dragImage = the image inside the DragBox, pushImage = the rest of the image excluding the contents of the box
        Rectangle2D bounds;                 //the bounds of the box, use this to tell when to drag and when to start a new box
        double startX, startY;              //the previous mouse position in drag gestures
        /**
         * Creates a new DragBox containing the desired image with the specified dimensions
         * @param dragImage image within the dimensions of the DragBox
         * @param pushImage the rest of the image on the Canvas
         * @param left the left-most point of the DragBox
         * @param top the upper-most point of the DragBox
         * @param width the width of the DragBox
         * @param height the height of the DragBox
         */
        public DragBox(WritableImage dragImage, WritableImage pushImage, double left, double top, double width, double height) {
            this.dragImage = dragImage;
            this.pushImage = pushImage;
            bounds = new Rectangle2D(left, top, width, height);
        }
        /**
         * 
         * @return the Rectangle2D representing the bounds of the DragBox
         */
        public Rectangle2D getBounds() {
            return bounds;
        }
        /**
         * 
         * @return the starting X value of the click-and-drag gesture
         */
        public double getStartX() {
            return startX;
        }
        /**
         * 
         * @return the starting Y value of the click-and-drag gesture
         */
        public double getStartY() {
            return startY;
        }
        /**
         * Sets the bounds of the DragBox
         * @param newBounds the Rectangle2D representing the new bounds of the DragBox
         */
        public void setBounds(Rectangle2D newBounds) {
            bounds = newBounds;
        }
        /**
         * Sets the starting X value of the click-and drag gesture
         * @param newX the new starting X value of the click-and-drag gesture
         */
        public void setStartX(double newX) {
            startX = newX;
        }
        /**
         * Sets the starting Y value of the click-and drag gesture
         * @param newY the new starting Y value of the click-and-drag gesture
         */
        public void setStartY(double newY) {
            startY = newY;
        }
        /**
         * Begins the click-and-drag gesture to drag the image within the DragBox 
         * to a new location, leaving a void at its original location
         * @param canvas the current Canvas
         * @param context GraphicsContext of the Canvas
         * @param undoStack Stack of changes made to the Canvas
         * @param startX the starting X value of the click-and-drag gesture
         * @param startY the starting Y value of the click-and-drag gesture
         */
        public void drag(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack, double startX, double startY) {
            setStartX(startX);
            setStartY(startY);
            canvas.setOnMousePressed((event) -> {
                System.out.println("Mouse Pressed");
                if (getBounds().contains(event.getX(), event.getY())) {
                    System.out.println(event.getX() + ", " + event.getY() + " within bounds of " + getBounds().toString());
                } else {
                    dragBox = null;
                    rect = new Rectangle(event.getX(), event.getY(), 0, 0);
                    context.beginPath();
                    context.moveTo(event.getX(), event.getY());
                    context.setStroke(Color.LIGHTGREY);
                    context.setLineWidth(1); //small black line to denote the DragBox
                    System.out.println("dragBox starting at " + rect.getX() + ", " + rect.getY());
                    Draw.selectDraw(canvas, context, undoStack);
                }
            });
            canvas.setOnMouseDragged((event) -> {
                if (event.isPrimaryButtonDown()) {
                    double dragX = getStartX() - event.getX();
                    double dragY = getStartY() - event.getY();
                    setStartX(event.getX());
                    setStartY(event.getY());
                    double width = getBounds().getWidth();
                    double height = getBounds().getHeight();
                    Rectangle2D newBounds = new Rectangle2D(getBounds().getMinX() - dragX, getBounds().getMinY() - dragY, width, height);
                    setBounds(newBounds);
                    context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                    context.drawImage(pushImage, 0, 0, canvas.getWidth(), canvas.getHeight());
                    context.drawImage(dragImage, getBounds().getMinX(), getBounds().getMinY(), getBounds().getWidth(), getBounds().getHeight());
                }
            });
            canvas.setOnMouseReleased((event) -> {
                if (event.getButton().equals(MouseButton.PRIMARY)) {
                    context.closePath();
                    WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                    canvas.snapshot(null, wImage);
                    undoStack.push(wImage);
                    System.out.println("bounds: " + getBounds().toString());
                    if (undoStack.peek() != null) {
                        System.out.println("Pushed");
                    }
                    context.setStroke(Color.LIGHTGREY);
                    context.setLineWidth(1); //small black line to denote the DragBox
                    context.strokeRect(getBounds().getMinX(), getBounds().getMinY(), getBounds().getWidth(), getBounds().getHeight());
                }
            });

        }
    }
}
