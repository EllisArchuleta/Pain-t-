/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintproject;

import java.util.Stack;
import javafx.scene.Group;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ColorPicker;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author micha
 */
public abstract class Draw implements DrawOperation{
    public static void freeHand(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack){
        Line line = new Line();
        canvas.setOnMousePressed((event) -> {
            context.beginPath();
            context.moveTo(event.getX(), event.getY());
            context.stroke();
            
        });
        
        canvas.setOnMouseDragged((event) -> {
            context.lineTo(event.getX(), event.getY());
            context.setStroke(colorPicker.getValue());
            context.stroke();
            
        });
        
        canvas.setOnMouseReleased((event) -> {
            context.closePath();
            WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
            canvas.snapshot(null,wImage);
            undoStack.push(wImage);
            if(undoStack.peek()!=null){System.out.println("Pushed");}
        });
    }
    public static void lineDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack){
        Line line = new Line();
        canvas.setOnMousePressed((event) -> {
            context.moveTo(event.getX(), event.getY());
            line.setStartX(event.getX());
            line.setStartY(event.getY());
            line.setEndX(event.getX());
            line.setEndY(event.getY());
        });
        canvas.setOnMouseDragged((event) -> {
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            WritableImage wImage = undoStack.peek();
            context.drawImage(wImage, 0, 0,canvas.getWidth(), canvas.getHeight());
            line.setEndX(event.getX());
            line.setEndY(event.getY());
            context.strokeLine(line.getStartX(), line.getStartY(), line.getEndX(), line.getEndY());

        });
        canvas.setOnMouseReleased((event) -> {
            WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
            canvas.snapshot(null,wImage);
            undoStack.push(wImage);
        });
    }
    public static void rectangleDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack){
        Rectangle rectangle = new Rectangle();
        Rectangle tempRectangle = new Rectangle();
        canvas.setOnMousePressed((event) -> {
            context.beginPath();
            context.moveTo(event.getX(), event.getY());
            rectangle.setX(event.getX());
            rectangle.setY(event.getY());
            tempRectangle.setX(rectangle.getX());
            tempRectangle.setY(rectangle.getY());
        });
        canvas.setOnMouseDragged((event)->{
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            WritableImage wImage = undoStack.peek();
            context.drawImage(wImage, 0, 0,canvas.getWidth(), canvas.getHeight());
            if(event.getX()<rectangle.getX()){
            //If the point you're at is further left than the current top left
                tempRectangle.setWidth(rectangle.getX() - event.getX());
                tempRectangle.setX(event.getX());
            //Then make that point the new top left corner and make the old corner the top right corner
            }
            else{tempRectangle.setWidth(event.getX() - rectangle.getX());}
            if(event.getY()<rectangle.getY()){
            //If the point you're at is further up than the current top left
                tempRectangle.setHeight(rectangle.getY() - event.getY());
                tempRectangle.setY(event.getY());
            //Then make that point the new top left corner and make the old corner the bottom left corner
            }
            else{tempRectangle.setHeight(event.getY() - rectangle.getY());}
            context.fillRect(tempRectangle.getX(),tempRectangle.getY(),tempRectangle.getWidth(),tempRectangle.getHeight());
        });
        canvas.setOnMouseReleased((event)->{
            WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
            canvas.snapshot(null,wImage);
            undoStack.push(wImage);
        });
    }
    public static void ellipseDraw(Canvas canvas, GraphicsContext context, ColorPicker colorPicker, Stack<WritableImage> undoStack){
      Ellipse ellipse = new Ellipse();
      Ellipse tempEllipse = new Ellipse();
      canvas.setOnMousePressed((event) -> {
            context.beginPath();
            context.moveTo(event.getX(), event.getY());
            ellipse.setCenterX(event.getX());
            ellipse.setCenterY(event.getY());
            tempEllipse.setCenterX(ellipse.getCenterX());
            tempEllipse.setCenterY(ellipse.getCenterY());
        });
      canvas.setOnMouseDragged((event)-> {
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            WritableImage wImage = undoStack.peek();
            context.drawImage(wImage, 0, 0,canvas.getWidth(), canvas.getHeight());
            double left;
            double top;
            double width;
            double height;
            if(event.getX()<ellipse.getCenterX()){
                left = event.getX();
                width = (ellipse.getCenterX()-event.getX());
            }
            else{
                left = ellipse.getCenterX();
                width = (event.getX()-ellipse.getCenterX());
            }
            if(event.getY()<ellipse.getCenterY()){
                top = event.getY();
                height = (ellipse.getCenterY()-event.getY());
            }
            else{
                top = ellipse.getCenterY();
                height = (event.getY() - ellipse.getCenterY());
            }
            context.fillOval(left, top, width, height);
      });
      canvas.setOnMouseReleased((event)-> {
            WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
            canvas.snapshot(null,wImage);
            undoStack.push(wImage);
      });
    }
    public static void colorGrabber(Canvas canvas, GraphicsContext context, ColorPicker colorPicker){
        canvas.setOnMousePressed((event) -> {
            System.out.println("Grabbing a Color");
            WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
            canvas.snapshot(null,wImage);
            PixelReader pixelReader = wImage.getPixelReader();
            colorPicker.setValue(pixelReader.getColor((int)event.getX(), (int)event.getY()));        
        });
        canvas.setOnMouseDragged((event)->{});
        canvas.setOnMouseReleased((event)->{});
    }
    public static void undo(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack, Stack<WritableImage> redoStack){
        if(undoStack.size()>1)//First make sure we're not clearing the pre-loaded image
        {
            //Clear out the canvas 
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            //Pop the undoStack into the redoStack and draw the next image
            redoStack.push(undoStack.pop());
            WritableImage wImage = undoStack.peek();
            canvas.setWidth(wImage.getWidth());                  
            canvas.setHeight(wImage.getHeight());
            context.drawImage(wImage, 0, 0,canvas.getWidth(), canvas.getHeight());
        }
    }
    public static void redo(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack, Stack<WritableImage> redoStack){
        if(redoStack.size()>0)//First make sure we're not clearing the pre-loaded image
        {
            //Clear out the canvas
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            //Pop the redoStack into the undoStack and draw the next image
            WritableImage wImage = redoStack.peek();
            undoStack.push(redoStack.pop());
            canvas.setWidth(wImage.getWidth());                  
            canvas.setHeight(wImage.getHeight());
            //And drawing the image on to it
            context.drawImage(wImage, 0, 0,canvas.getWidth(), canvas.getHeight());
        }
    }
    public static void zoomIn(Canvas canvas){
        canvas.setScaleX(canvas.getScaleX()+0.25);
        canvas.setScaleY(canvas.getScaleY()+0.25);
    }
    public static void zoomOut(Canvas canvas){
        if(canvas.getScaleX()>0 && canvas.getScaleY()>0){
        canvas.setScaleX(canvas.getScaleX()-0.25);
        canvas.setScaleY(canvas.getScaleY()-0.25);
        }
        //canvas.setWidth(canvas.getWidth()*canvas.getScaleX());
        //canvas.setHeight(canvas.getHeight()*canvas.getScaleY());
    }
}
