/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintproject;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.stage.Stage;

/**
 * A timer used for each CanvasTab to implement auto-save and logging methods
 * 
 */
public class AutoLogger {

    static Timer timer;
    static String log = "";
    static long countdownMax = 120;
    /**
     * Starts a timer for the given CanvasTab which will save the file, if any, every 2 minutes and log the current save status and drawing tool every 1 minute, updating the tab's countdown every second
     * @param primaryStage The Stage of the program
     * @param tab The CanvasTab being saved and logged
     * @param n The index of the CanvasTab
     */
    public static void startTimer(Stage primaryStage, CanvasTab tab, int n) {
        timer = new Timer(true);
        timer.schedule(
                new TimerTask() {

            @Override
            public void run() {
                Platform.runLater(() -> {
                    if (tab.getFile() != null) {
                        try {
                            Menus.saveFile(primaryStage, tab);
                        } catch (IOException ex) {
                            Logger.getLogger(AutoLogger.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        System.out.println("Saving tab " + n);
                    } else {
                        System.out.println("Can't save tab " + n);
                    }
                    tab.setCountdown(countdownMax);
                    
                });
            }
        }, 0, countdownMax*1000);
        timer.schedule(
                new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    Date date = new Date();
                    log+=date+": " +tab.getText() + ":   Saved = " + tab.getSaved() +"  Tool = " + tab.getTool().toString() +"\n";
                    try (PrintWriter out = new PrintWriter("PaintLog.txt")) {
                    out.println(log);
}                   catch (FileNotFoundException ex) {
                        Logger.getLogger(AutoLogger.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    System.out.println(log);
                });
            }
        }, 0, 60000);
        timer.schedule(
                new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    tab.updateCountdown();
                });
            }
        }, 0, 1000);
    }

}
