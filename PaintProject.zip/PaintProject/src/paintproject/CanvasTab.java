/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintproject;

import java.io.File;
import java.util.Stack;
import javafx.scene.Group;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.WritableImage;

/**
 * An aggregator of all the necessary information for editing and saving images
 * on a Canvas (a la Paint), for the purposes of adding to a TabPane with multiple instances
 * 
 */

public class CanvasTab extends Tab{
    Canvas canvas;
    Group canvasGroup;
    ScrollPane scroller;
    GraphicsContext context;
    Stack<WritableImage> undoStack;
    Stack<WritableImage> redoStack;
    File file;
    static Boolean saved;
    static long countdownMax = 120;
    long countdown;
    Label countdownLabel;
    Toggle tool;
    /**
     * Creates an empty CanvasTab with the given name.
     * @param text The title of the Tab
     */
    public CanvasTab(String text){
        super(text);
        canvas = new Canvas(800,800);
        canvasGroup = new Group();
        context = canvas.getGraphicsContext2D();
        scroller = new ScrollPane();
        scroller.setContent(canvasGroup);
        canvasGroup.getChildren().addAll(canvas,scroller);
        scroller.maxWidthProperty().bind(canvas.widthProperty());
        undoStack = new Stack<>();
        //Initializing the undoStack
        WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
        undoStack.push(wImage); 
        redoStack = new Stack<>();
        setContent(scroller);
        file = null;
        saved = true;
        countdown = countdownMax;
        countdownLabel = new Label("Saving in " + countdown + " seconds");
    }
    /**
     * Gets the tab's Canvas
     * @return The canvas on which images are edited
     */
    public Canvas getCanvas(){
        return canvas;
    }
    /**
     * Sets the canvas
     * @param newCanvas The canvas on which images are edited
     */
    public void setCanvas(Canvas newCanvas){
        canvas = newCanvas;
    }
    /**
     * Gets the group of the tab
     * @return The tab's group for scrolling
     */
    public Group getGroup(){
        return canvasGroup;
    }
    /**
     * Sets the group of the tab
     * @param newGroup The tab's group for scrolling
     */
    public void setGroup(Group newGroup){
        canvasGroup = newGroup;
    }
    /**
     * Gets the ScrollPane of the tab
     * @return the ScrollPane for scrolling the image on the canvas
     */
    public ScrollPane getScroller(){
        return scroller;
    }
    /**
     * Sets the ScrollPane of the tab
     * @param newScroller the ScrollPane for scrolling the image on the canvas
     */
    public void setScroller(ScrollPane newScroller){
        scroller = newScroller;
    }
    /**
     * Gets the GraphicsContext of the tab
     * @return the GraphicsContext used to draw on the Canvas
     */
    public GraphicsContext getContext(){
        return context;
    }
    /**
     * Sets the GraphicsContext of the tab
     * @param newContext the GraphicsContext used to draw on the Canvas
     */
    public void setContext(GraphicsContext newContext){
        context = newContext;
    }
    /**
     * Gets the undoStack of the tab
     * @return The stack of changes made to the Canvas
     */
    public Stack<WritableImage> getUndoStack(){
        return undoStack;
    }
    /**
     * Gets the redoStack of the tab
     * @return The stack of changes to the Canvas that have been undone
     */
    public Stack<WritableImage> getRedoStack(){
        return redoStack;
    }
    /**
     * Gets the current open file
     *
     * @return the destination of the currently opened file
     */
    public File getFile() {
        return file;
    }

    /**
     * Sets a new file to be opened
     *
     * @param newFile the destination of the file to be opened
     */
    public void setFile(File newFile) {
        file = newFile;
    }
    /**
     * Returns a Boolean which states whether or not the image has been edited
     * since the last save.
     * <p>
     * Called when changes to the image could potentially be overwritten
     *
     * @return the Boolean saved
     */
    public boolean getSaved() {
        return saved;
    }

    /**
     * Sets the value of saved
     *
     * @param newSaved a Boolean stating whether or not the image has been
     * edited
     */
    public void setSaved(boolean newSaved) {
        saved = newSaved;
        setCountdown(countdownMax);
    }
    /**
     * 
     * @return the Label representing the seconds before the next auto-save
     */
    public Label getCountdownLabel(){
        return countdownLabel;
    }
    /**
     * Sets the value of countdown
     * @param newCount the new value being counted down from
     */
    public void setCountdown(long newCount){
        countdown = newCount;
    }
    /**
     * Gets the value of countdown
     * @return the current countdown (in seconds) until the next auto-save
     */
    public long getCountdown(){
        return countdown;
    }
    /**
     * Counts down the Label representing the auto-save Timer
     */
    public void updateCountdown(){
        countdown--;
        countdownLabel.setText("Saving in " + countdown + "seconds");
    }
    /**
     * Sets the drawing tool being used by the tab
     * @param newTool The Toggle representing which Tool has been selected
     */
    public void setTool(Toggle newTool){
        tool = newTool;
    }
    /**
     * Gets the value of the Toggle tool
     * @return The drawing tool being used by the tab
     */
    public Toggle getTool(){
        return tool;
    }
}
