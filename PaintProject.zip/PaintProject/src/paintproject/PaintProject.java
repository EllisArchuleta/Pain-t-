
package paintproject;

import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

public class PaintProject extends Application {
    File file = null;
    Image image = new Image("file:blank.png");
   
    PixelReader pixelReader = image.getPixelReader(); 
    ColorPicker colorPicker = new ColorPicker(Color.BLACK);
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        BorderPane border = new BorderPane();
        Canvas canvas = new Canvas(800,800);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        ScrollPane scroller = new ScrollPane();
        final Slider widthSlider = new Slider(1,15,3);
        
        initDraw(gc);
        
        
        
        scroller.setContent(canvas);
        scroller.maxWidthProperty().bind(border.widthProperty());
        border.setRight(scroller);
        
        
        
        border.setCenter(canvas); //Setting the Canvas as center for overlap
        
        
        //Setting up the Menu Bar
        MenuBar menuBar = new MenuBar();
        Menu menuFile = new Menu("File");
        MenuItem menuOpen = new MenuItem("Open");
        menuOpen.setOnAction((ActionEvent t) -> {
            final FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Select an Image");
            configureFileChooser(fileChooser);
            file = fileChooser.showOpenDialog(primaryStage);
            if(file!=null){
                image = new Image(file.toURI().toString());
                gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                canvas.setWidth(image.getWidth());
                canvas.setHeight(image.getHeight());
                
                
                gc.drawImage(image, 0, 0,canvas.getWidth(), canvas.getHeight());
                
                
                
                pixelReader = image.getPixelReader();
                initDraw(gc);
            }
        }); 
        
        MenuItem menuSave = new MenuItem("Save"); 
        menuSave.setOnAction((ActionEvent t) -> {
            if (file != null) {
                try {
                    System.out.println("Saving File!");
                    WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
                    canvas.snapshot(null,wImage);
                    RenderedImage renderedImage = SwingFXUtils.fromFXImage(wImage,null);
                    ImageIO.write(renderedImage,"png",file);
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            else{
                try {
                    saveFile(primaryStage,canvas);
                } catch (IOException ex) {
                    Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        MenuItem menuSaveAs = new MenuItem("Save As");
        menuSaveAs.setOnAction(e->{
            try {
                saveFile(primaryStage, canvas);
            } catch (IOException ex) {
                Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        MenuItem menuExit = new MenuItem("Exit");
        menuExit.setOnAction(e -> Platform.exit());
        
        menuFile.getItems().addAll(menuOpen,menuSave,menuSaveAs,menuExit);//Adding Items to the File menu

        
        Menu menuHelp = new Menu("Help");
        MenuItem menuAbout = new MenuItem("About");
        Alert about = new Alert(AlertType.INFORMATION);
        about.setTitle("About");
        about.setHeaderText(null);
        about.setContentText("This is the meaning of Pain(t)");
        menuAbout.setOnAction(e->{
            about.showAndWait();
        });
        menuHelp.getItems().add(menuAbout);
        menuBar.getMenus().addAll(menuFile,menuHelp);//Adding Menus to the Bar
        menuBar.setMinHeight(32);//Configuring the Menubar
        menuBar.maxWidthProperty().bind(border.widthProperty());
        
        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, (MouseEvent event) -> {
            gc.beginPath();
            gc.moveTo(event.getX(), event.getY());
            gc.setStroke(colorPicker.getValue());
            gc.stroke();
        });
        
        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, (MouseEvent event) -> {
            gc.lineTo(event.getX(), event.getY());
            gc.setStroke(colorPicker.getValue());
            gc.stroke();
        });
        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, (MouseEvent event) -> {
        });
        
        widthSlider.setMajorTickUnit(1);
        widthSlider.setSnapToTicks(true);
        widthSlider.setShowTickMarks(true);
        widthSlider.setShowTickLabels(true);
        widthSlider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            gc.setLineWidth(new_val.doubleValue());
        });
        
        HBox hbox = new HBox();
        hbox.getChildren().addAll(colorPicker,widthSlider);
        border.setTop(hbox);
        VBox vbox = new VBox();
        vbox.getChildren().addAll(menuBar, hbox);
        border.setTop(vbox);//Adding it all to the BorderPane
        Scene scene = new Scene(border, border.getWidth(), border.getHeight());
        primaryStage.setTitle("Paint Project");
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true);
        primaryStage.show();         
    }
    public void saveFile(Stage primaryStage, Canvas canvas) throws IOException{
        FileChooser fileSaver = new FileChooser();
        fileSaver.setTitle("Save Image");
        configureFileChooser(fileSaver);
        File saveFile = fileSaver.showSaveDialog(primaryStage);
        if (saveFile != null) {
            try{
                WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
                canvas.snapshot(null,wImage);
                
                RenderedImage renderedImage = SwingFXUtils.fromFXImage(wImage,null);
                ImageIO.write(renderedImage,"png",saveFile);
            }catch (IOException ex) {
                        Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("Saving");
        }
        
    }
    public static void configureFileChooser(final FileChooser fileChooser)
    {
        
        fileChooser.setInitialDirectory(
        new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("All Images", "*.jpg", "*.jpeg",""
                    + "*.jfif","*.jpe","*.png","*.gif","*.tif","*.tiff",
                    "*.ico","*.heic","*.webp"),
            new FileChooser.ExtensionFilter("JPEG", "*.jpg", "*.jpeg","*.jfif","*.jpe"),
            new FileChooser.ExtensionFilter("PNG","*.png"),
            new FileChooser.ExtensionFilter("GIF","*.gif"),
            new FileChooser.ExtensionFilter("TIFF","*.tif","*.tiff"),
            new FileChooser.ExtensionFilter("ICO","*.ico"),
            new FileChooser.ExtensionFilter("HEIC","*.heic"),
            new FileChooser.ExtensionFilter("WEBP","*.webp")
        );  
        
        
    }
    private void initDraw(GraphicsContext gc){
        
        double canvasWidth = gc.getCanvas().getWidth();
        double canvasHeight = gc.getCanvas().getHeight();
        System.out.println(canvasWidth);
        System.out.println(canvasHeight);
        gc.setFill(colorPicker.getValue());
        gc.setStroke(colorPicker.getValue());
        gc.setLineWidth(10);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
