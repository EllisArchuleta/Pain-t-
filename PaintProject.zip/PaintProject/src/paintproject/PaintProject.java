package paintproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Optional;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.MenuItemBuilder;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * Main class of the image editor
 *
 * @author Ellis Archuleta
 */
public class PaintProject extends Application {

    File file = null;                           //file = whatever while is currently open
    //initialized to a blank canvas
    //ResizableCanvas canvas = new ResizableCanvas(800,800);    
    //Canvas canvas = new Canvas(800, 800);        //New Canvas of an arbitrary size
    ColorPicker colorPicker = new ColorPicker(Color.BLACK);
    int tabIndex = 0;
    int maxIndex = 0;
    //Boolean saved = true;

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        BorderPane border = new BorderPane();
        TabPane tabPane = new TabPane();
        //Can't figure out how to tell it that it's of size 10 with them all being null other than this 
        CanvasTab[] tabs = {null, null, null, null, null, null, null, null, null, null};
        tabs[0] = new CanvasTab("Tab1");

        AutoLogger.startTimer(primaryStage, tabs[0], 0); //Each tab has it's own autosave timer
        //Tab tab1 = new Tab("Tab 1");
        Tab newTab = new Tab("+");
        /*Group[] canvasGroup = {null,null,null,null,null,null,null,null,null,null};
        
        for(int i = 0;i<10;i++){
            canvasGroup[i] = new Group();
        }
        canvasGroup[0].getChildren().add(canvas);*/
        //tab1.setContent(canvasGroup[0]);
        //GraphicsContext context = canvas.getGraphicsContext2D();
        newTab.setOnSelectionChanged(event -> {
            if (maxIndex < 9) {
                // create Tab 
                System.out.println("New tab");
                maxIndex++;
                tabs[tabIndex] = new CanvasTab("Tab " + (int) (tabIndex + 1));
                //Initialize the new tab
                tabs[tabIndex].getContext().setFill(Color.WHITE);
                tabs[tabIndex].getContext().fillRect(0, 0, tabs[tabIndex].getCanvas().getWidth(), tabs[tabIndex].getCanvas().getHeight());
                AutoLogger.startTimer(primaryStage, tabs[tabIndex], tabIndex);
                //Add tab to the pane
                tabPane.getTabs().add(
                        tabPane.getTabs().size() - 1, tabs[tabIndex]);

                // select the last tab 
                tabPane.getSelectionModel().select(
                        tabPane.getTabs().size() - 2);
            } else {
                tabPane.getSelectionModel().select(tabIndex);
            }
        });
        tabPane.getTabs().addAll(tabs[0], newTab);

        /*ScrollPane scroller = new ScrollPane();
        Stack<WritableImage> undoStack = new Stack<>();
        WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
        undoStack.push(wImage); //Initializing the undoStack
        Stack<WritableImage> redoStack = new Stack<>();*/
        final Slider widthSlider = new Slider(1, 15, 3);
        final Slider opacitySlider = new Slider(0, 1.0, 1.0);
        final Label widthLabel = new Label("    Line Width: ");
        final Label widthValueLabel = new Label(String.format(" %.2f     ", widthSlider.getValue()));
        final Label opacityLabel = new Label(" Opactiy: ");
        final Label opacityValueLabel = new Label(String.format(" %.2f     ", opacitySlider.getValue()));
        final HBox bottomBox = new HBox();
        CheckBox countdownCheck = new CheckBox();
        countdownCheck.setText("See Autosave countdown?      ");
        countdownCheck.setSelected(true);
        countdownCheck.selectedProperty().addListener((obs, ov, nv) -> {
            if (countdownCheck.isSelected()) {
                tabs[tabIndex].getCountdownLabel().setVisible(true);
            } else {
                tabs[tabIndex].getCountdownLabel().setVisible(false);
            }

        });

        bottomBox.getChildren().addAll(countdownCheck, tabs[tabIndex].getCountdownLabel());
        border.setBottom(bottomBox);
        //scroller.setContent(canvasGroup[0]);
        //scroller.maxWidthProperty().bind(canvas.widthProperty());
        //border.setRight(scroller);

        //Initializing the Canvas to show a blank white screen
        tabs[tabIndex].getContext().setFill(Color.WHITE);
        tabs[tabIndex].getContext().fillRect(0, 0, tabs[tabIndex].getCanvas().getWidth(), tabs[tabIndex].getCanvas().getHeight());

        //Setting the Canvas as center early so it doesn't cover anything up
        //border.setCenter(scroller);
        border.setCenter(tabPane);

        //Creating the Toggles representing the drawing tools of the program   
        ToggleGroup group = new ToggleGroup();
        ToggleButton freeHandDraw = new ToggleButton("Free Hand");
        freeHandDraw.setToggleGroup(group);
        ToggleButton eraserDraw = new ToggleButton("Eraser");
        eraserDraw.setToggleGroup(group);
        ToggleButton selectDraw = new ToggleButton("Select");
        selectDraw.setToggleGroup(group);
        ToggleButton lineDraw = new ToggleButton("Line");
        lineDraw.setToggleGroup(group);
        ToggleButton rectangleDraw = new ToggleButton("Rectangle");
        rectangleDraw.setToggleGroup(group);
        ToggleButton squareDraw = new ToggleButton("Square");
        squareDraw.setToggleGroup(group);
        ToggleButton ellipseDraw = new ToggleButton("Ellipse");
        ellipseDraw.setToggleGroup(group);
        ToggleButton circleDraw = new ToggleButton("Circle");
        circleDraw.setToggleGroup(group);
        ToggleButton rhombusDraw = new ToggleButton("Rhombus");
        rhombusDraw.setToggleGroup(group);
        ToggleButton polygonDraw = new ToggleButton("Polygon");
        polygonDraw.setToggleGroup(group);
        ToggleButton textDraw = new ToggleButton("Text");
        textDraw.setToggleGroup(group);
        ToggleButton colorGrabber = new ToggleButton("Grab Color");
        colorGrabber.setToggleGroup(group);

        //Setting the freeHand tool as selected by default, as well as the freeHand method
        freeHandDraw.setSelected(true);
        Draw.freeHand(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());//Starting with freeHand draw as the default

        //Added tooltips to tools whose functions aren't entirely apparent from the name
        Tooltip selectTooltip = new Tooltip("Select an area and drag it!");
        Tooltip.install(selectDraw, selectTooltip);
        Tooltip polygonTooltip = new Tooltip("Draw a polygon with any number of sides!");
        Tooltip.install(polygonDraw, polygonTooltip);
        Tooltip textTooltip = new Tooltip("Put text anywhere in your image!");
        Tooltip.install(textDraw, textTooltip);
        Tooltip grabberTooltip = new Tooltip("Pick any color in your image!");
        Tooltip.install(colorGrabber, grabberTooltip);

        //Make the ToggleGroup begin the method respective to the Toggle selected
        //Tools that cause immediate changes to the canvas will first clear out the redoStack
        group.selectedToggleProperty().addListener((ObservableValue<? extends Toggle> ov, Toggle old_val, Toggle new_val) -> {
            Draw.dragBox = null;
            WritableImage resetImage = tabs[tabIndex].getUndoStack().peek();
            tabs[tabIndex].getContext().clearRect(0, 0, tabs[tabIndex].getCanvas().getWidth(), tabs[tabIndex].getCanvas().getHeight());
            tabs[tabIndex].getContext().drawImage(resetImage, 0, 0);
            tabs[tabIndex].setTool(new_val);
            if (new_val == freeHandDraw) {
                System.out.println("freehand");
                Draw.freeHand(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());     //See Draw class for drawing functions
                tabs[tabIndex].getRedoStack().removeAllElements();

            }
            if (new_val == eraserDraw) {
                Draw.eraserDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), tabs[tabIndex].getUndoStack());
                tabs[tabIndex].getRedoStack().removeAllElements();
            }
            if (group.getSelectedToggle() == selectDraw) {
                System.out.println("dragBox");
                Draw.selectDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), tabs[tabIndex].getUndoStack());
            }
            if (new_val == lineDraw) {
                System.out.println("line");
                Draw.lineDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());
                tabs[tabIndex].getRedoStack().removeAllElements();
            }
            if (new_val == rectangleDraw) {
                System.out.println("rect");
                Draw.rectangleDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());
                tabs[tabIndex].getRedoStack().removeAllElements();
            }
            if (new_val == squareDraw) {
                Draw.squareDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());
                tabs[tabIndex].getRedoStack().removeAllElements();
            }
            if (new_val == ellipseDraw) {
                System.out.println("ellipse");
                Draw.ellipseDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());
                tabs[tabIndex].getRedoStack().removeAllElements();
            }
            if (new_val == circleDraw) {
                Draw.circleDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());
                tabs[tabIndex].getRedoStack().removeAllElements();
            }
            if (new_val == rhombusDraw) {
                Draw.rhombusDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());
                tabs[tabIndex].getRedoStack().removeAllElements();
            }
            if (new_val == polygonDraw) {
                //First need to ask for the number of sides, then send that number to the method
                Dialog<Double> dialog = new Dialog<>();
                dialog.setTitle("How many sides should this polygon have?");
                dialog.setHeaderText(null);
                TextField sidesField = new TextField();
                sidesField.setPromptText("x");
                dialog.getDialogPane().setContent(sidesField);
                dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
                dialog.setResultConverter(dialogButton -> {
                    if (dialogButton == ButtonType.OK) {
                        Double newSize = Double.parseDouble(sidesField.getText());
                        return newSize;
                    }
                    return null;
                });
                Optional<Double> nSides = dialog.showAndWait();
                Draw.polygonDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack(), nSides.get());
            }
            if (new_val == textDraw) {
                //First asks for the desired text, then sends that to the method
                TextInputDialog dialog = new TextInputDialog("Input text here");
                String inputText = dialog.showAndWait().get();
                Draw.textDraw(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), widthSlider, opacitySlider, colorPicker, tabs[tabIndex].getUndoStack(), inputText);

            }
            if (new_val == colorGrabber) {
                System.out.println("fgrabber");
                Draw.colorGrabber(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker);
            }
            if (new_val == null) {
                //If all toggles are deselected, then stop the canvas from doing anything
                tabs[tabIndex].getCanvas().setOnMousePressed((e) -> {
                });
                tabs[tabIndex].getCanvas().setOnMouseDragged((e) -> {
                });
                tabs[tabIndex].getCanvas().setOnMouseReleased((e) -> {
                });
            }
        });
        //Making sure to initialize the which tool the first tab is using
        tabs[0].setTool(group.getSelectedToggle());

        //Make sure we're keeping track of which tab is selected and update necessary values
        tabPane.getSelectionModel().selectedItemProperty().addListener((obs, ov, nv) -> {
            //index<10 so that we don't accidentally select the "new tab" while at maximum tabs (index=9)
            if (tabPane.getSelectionModel().getSelectedIndex() < 10) {
                //Revert to default drawing settings when you change tabs (for safety purposes)
                freeHandDraw.setSelected(true); 
                Draw.freeHand(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), colorPicker, tabs[tabIndex].getUndoStack());
                //Update the index when you change tabs
                tabIndex = tabPane.getSelectionModel().getSelectedIndex(); 
                //Swap in the autosave timer/label for the selected tab
                bottomBox.getChildren().clear();
                tabs[tabIndex].getCountdownLabel().setVisible(countdownCheck.isSelected());
                tabs[tabIndex].setTool(group.getSelectedToggle());
                bottomBox.getChildren().addAll(countdownCheck, tabs[tabIndex].getCountdownLabel());
            } else {
                System.out.println("Blocked tab");
            }
        });
        tabPane.addEventHandler(MouseEvent.MOUSE_PRESSED, (MouseEvent event) -> {
            //This is the list of items that should always happen when drawing
            //The code for the drawing tools themselves are within the Draw class,
            //referenced 
            if ((event.getButton().equals(MouseButton.PRIMARY))) {
                tabs[tabIndex].getContext().clearRect(0, 0, tabs[tabIndex].getCanvas().getWidth(), tabs[tabIndex].getCanvas().getHeight());
                WritableImage undoImage = tabs[tabIndex].getUndoStack().peek();
                tabs[tabIndex].getContext().drawImage(undoImage, 0, 0, tabs[tabIndex].getCanvas().getWidth(), tabs[tabIndex].getCanvas().getHeight());
                Color fillColor = colorPicker.getValue().deriveColor(1, 1, 1, opacitySlider.getValue());
                tabs[tabIndex].getContext().setFill(fillColor);
                tabs[tabIndex].getContext().setStroke(fillColor);
                tabs[tabIndex].getContext().setLineWidth(widthSlider.getValue());
                if (!(group.getSelectedToggle() == colorGrabber || group.getSelectedToggle() == selectDraw || group.getSelectedToggle() == null)) {
                    tabs[tabIndex].getRedoStack().removeAllElements();      //Clearing out the redo stack whenever we do something that would add to the undo stack
                }
            }
            tabs[tabIndex].setSaved(false);
            //saved = false;
        });

        MenuBar menuBar = new MenuBar();
        Menu menuFile = new Menu("File");

        //Open
        MenuItem menuOpen;
        menuOpen = MenuItemBuilder.create()
                .text("Open")
                .accelerator(new KeyCodeCombination(KeyCode.O, KeyCombination.CONTROL_DOWN))
                .onAction(e -> {
                    try {
                        File newFile = Menus.openFile(primaryStage, tabs[tabIndex]);
                        tabs[tabIndex].setFile(newFile);
                        tabs[tabIndex].setFile(newFile);
                        if (tabs[tabIndex].getFile() == null) {
                            System.out.println("File null");
                        }
                    } catch (IOException ex) {
                        Logger.getLogger(PaintProject.class
                                .getName()).log(Level.SEVERE, null, ex);
                    }
                })
                .build();

        //Save
        MenuItem menuSave = MenuItemBuilder.create()
                .text("Save")
                .accelerator(new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN))
                .onAction(e -> {
                    try {
                        if (tabs[tabIndex].getFile() == null) {
                            System.out.println("File null");
                        }
                        Menus.saveFile(primaryStage, tabs[tabIndex]);
                        //saved = true;
                        tabs[tabIndex].setSaved(true);
                    } catch (IOException ex) {
                        Logger.getLogger(PaintProject.class
                                .getName()).log(Level.SEVERE, null, ex);
                    }
                })
                .build();

        //SaveAs
        MenuItem menuSaveAs = MenuItemBuilder.create()
                .text("SaveAs")
                .accelerator(new KeyCodeCombination(KeyCode.F12, KeyCombination.CONTROL_ANY))
                .onAction(e -> {
                    try {
                        Menus.saveAsFile(primaryStage, tabs[tabIndex].getCanvas());
                        tabs[tabIndex].setSaved(true);
                    } catch (IOException ex) {
                        Logger.getLogger(PaintProject.class
                                .getName()).log(Level.SEVERE, null, ex);
                    }
                })
                .build();

        //Exit
        MenuItem menuExit = new MenuItem("Exit");
        menuExit.setOnAction(e -> {
            try {
                Menus.Exit(primaryStage, tabs[tabIndex]);
            } catch (IOException ex) {
                Logger.getLogger(PaintProject.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        });

        primaryStage.setOnCloseRequest(e -> {
            try {
                Menus.Exit(primaryStage, tabs[tabIndex]);
            } catch (IOException ex) {
                Logger.getLogger(PaintProject.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
            e.consume();
        });

        //Adding Items to the File menu
        menuFile.getItems().addAll(menuOpen, menuSave, menuSaveAs, menuExit);

        Menu menuEdit = new Menu("Edit");
        //Undo
        MenuItem menuUndo = MenuItemBuilder.create()
                .text("Undo")
                .accelerator(new KeyCodeCombination(KeyCode.Z, KeyCombination.CONTROL_DOWN))
                .onAction(e -> Draw.undo(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), tabs[tabIndex].getUndoStack(), tabs[tabIndex].getRedoStack()))
                .build();
        //Redo
        MenuItem menuRedo = MenuItemBuilder.create()
                .text("Redo")
                .accelerator(new KeyCodeCombination(KeyCode.Y, KeyCombination.CONTROL_DOWN))
                .onAction(e -> Draw.redo(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), tabs[tabIndex].getUndoStack(), tabs[tabIndex].getRedoStack()))
                .build();

        //Adding Items to the Edit Menu
        menuEdit.getItems().addAll(menuUndo, menuRedo);

        Menu menuView = new Menu("View");
        //Zoom In
        MenuItem menuZoomIn = MenuItemBuilder.create()
                .text("Zoom IN")
                .accelerator(new KeyCodeCombination(KeyCode.EQUALS, KeyCombination.CONTROL_DOWN))
                .onAction(e -> Draw.zoomIn(tabs[tabIndex].getCanvas()))
                .build();
        //Zoom out
        MenuItem menuZoomOut = MenuItemBuilder.create()
                .text("Zoom OUT")
                .accelerator(new KeyCodeCombination(KeyCode.MINUS, KeyCombination.CONTROL_DOWN))
                .onAction(e -> Draw.zoomOut(tabs[tabIndex].getCanvas()))
                .build();
        //Making CTRL+Scroll-Up and CTRL+Scroll-Down zoom in or out, respectively
        //As secondary hotkeys essentially
        tabs[tabIndex].getCanvas().addEventHandler(ScrollEvent.SCROLL, (ScrollEvent event) -> {
            if (event.isControlDown()) {
                if (event.getDeltaY() > 0) {
                    System.out.println("Zooming In");
                    Draw.zoomIn(tabs[tabIndex].getCanvas());
                }
                if (event.getDeltaY() < 0) {
                    System.out.println("Zooming Out");
                    Draw.zoomOut(tabs[tabIndex].getCanvas());
                }
            } else {
                System.out.println("Scrolling");
            }
        });

        //Resize
        MenuItem menuResize = MenuItemBuilder.create()
                .text("Resize")
                .onAction(e -> Menus.resize(tabs[tabIndex].getCanvas(), tabs[tabIndex].getContext(), tabs[tabIndex].getUndoStack()))
                .build();

        //Adding Items to the View menu
        menuView.getItems().addAll(menuZoomIn, menuZoomOut, menuResize);

        Menu menuHelp = new Menu("Help");

        //Help>About
        MenuItem menuAbout = MenuItemBuilder.create()
                .text("About")
                .onAction(e -> {
                    try {
                        Menus.menuAbout();
                    } catch (FileNotFoundException ex) {
                        System.out.println("About Error");
                        Logger.getLogger(Menus.class.getName()).log(Level.SEVERE, null, ex);
                    }
                })
                .build();
        menuHelp.getItems().add(menuAbout);

        //Adding Menus to the Bar
        menuBar.getMenus().addAll(menuFile, menuEdit, menuView, menuHelp);
        menuBar.setMinHeight(32);//Configuring the Menubar
        menuBar.maxWidthProperty().bind(border.widthProperty());

        //Configuring the Slider for ease of use
        widthSlider.setMajorTickUnit(1);
        widthSlider.setSnapToTicks(true);
        widthSlider.setShowTickMarks(true);
        widthSlider.setShowTickLabels(true);
        opacitySlider.setMajorTickUnit(1);
        opacitySlider.setSnapToTicks(true);
        opacitySlider.setShowTickMarks(true);
        opacitySlider.setShowTickLabels(true);
        //Moving the slider changes the width of the line
        widthSlider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            widthValueLabel.setText(" " + String.format("%.2f     ", new_val));
        });
        opacitySlider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            opacityValueLabel.setText(" " + String.format("%.2f     ", new_val));
        });
        //The ColorPicker, Sliders and Toggles for all the drawing tools hang out
        //on the same horizontal line above the canvas
        HBox hbox = new HBox();
        hbox.getChildren().addAll(
                colorPicker, widthLabel, widthSlider, widthValueLabel,
                opacityLabel, opacitySlider, opacityValueLabel, freeHandDraw,
                eraserDraw, selectDraw, lineDraw, rectangleDraw, squareDraw,
                ellipseDraw, circleDraw, rhombusDraw, polygonDraw, textDraw, colorGrabber);
        border.setTop(hbox);

        //And the MenuBar sits on the top of that row
        VBox vbox = new VBox();
        vbox.getChildren().addAll(menuBar, hbox);
        border.setTop(vbox);//Adding it all to the BorderPane
        Scene scene = new Scene(border, tabs[tabIndex].getCanvas().getWidth(), tabs[tabIndex].getCanvas().getHeight());

        primaryStage.setTitle("Paint Project");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
