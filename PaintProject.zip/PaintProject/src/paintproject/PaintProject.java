
package paintproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

public class PaintProject extends Application {
    
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        BorderPane border = new BorderPane();
        ImageView view = new ImageView();  
        border.setCenter(view);
        
        //Setting up the Menu Bar
        MenuBar menuBar = new MenuBar();
        Menu menuFile = new Menu("File");
        
        MenuItem menuOpen = new MenuItem("Open");
        //"Open" uses openImage to open an image (fancy that!)
        menuOpen.setOnAction(new EventHandler<ActionEvent>()
        {
            public void handle(ActionEvent t) {
                final FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Select an Image");
                configureFileChooser(fileChooser);
                File file = fileChooser.showOpenDialog(primaryStage);
                if(file!=null){
                    Image image = new Image(file.toURI().toString());
                    view.setImage(image);
                    ScrollPane scroller = new ScrollPane();
                    scroller.setContent(view);
                    scroller.maxWidthProperty().bind(border.widthProperty());
                    border.setRight(scroller);
                    view.setPreserveRatio(true);
                }
            }
        }); 
        
        MenuItem menuSave = new MenuItem("Save"); //Saves current image
        menuSave.setOnAction(new EventHandler<ActionEvent>()
        {
            public void handle(ActionEvent t) {
                FileChooser fileSaver = new FileChooser();
                fileSaver.setTitle("Save Image");
                System.out.println(view.getId());
                configureFileChooser(fileSaver);
                File file = fileSaver.showSaveDialog(primaryStage);
                if (file != null) {
                try {
                    ImageIO.write(SwingFXUtils.fromFXImage(view.getImage(),
                        null), "png", file);
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            }
        });
        
        MenuItem menuExit = new MenuItem("Exit");
        menuExit.setOnAction(e -> Platform.exit());
        
        menuFile.getItems().add(menuOpen);//Adding Items to the File menu
        menuFile.getItems().add(menuSave);
        menuFile.getItems().add(menuExit);
        
        menuBar.getMenus().addAll(menuFile);//Adding File to the Bar
        menuBar.setMinHeight(32);//Configuring the Menubar
        menuBar.maxWidthProperty().bind(border.widthProperty());
        border.setTop(menuBar);//Adding it all to the BorderPane
        Scene scene = new Scene(border, border.getWidth(), border.getHeight());
        primaryStage.setTitle("Paint Project");
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true);
        primaryStage.show();         
    }
    
    public static void configureFileChooser(final FileChooser fileChooser)
    {
        
        fileChooser.setInitialDirectory(
        new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("All Images", "*.jpg", "*.jpeg",""
                    + "*.jfif","*.jpe","*.png","*.gif","*.tif","*.tiff",
                    "*.ico","*.heic","*.webp"),
            new FileChooser.ExtensionFilter("JPEG", "*.jpg", "*.jpeg","*.jfif","*.jpe"),
            new FileChooser.ExtensionFilter("PNG","*.png"),
            new FileChooser.ExtensionFilter("GIF","*.gif"),
            new FileChooser.ExtensionFilter("TIFF","*.tif","*.tiff"),
            new FileChooser.ExtensionFilter("ICO","*.ico"),
            new FileChooser.ExtensionFilter("HEIC","*.heic"),
            new FileChooser.ExtensionFilter("WEBP","*.webp")
        );  
        
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
