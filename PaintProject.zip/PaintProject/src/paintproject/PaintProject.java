
package paintproject;

import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.MenuItemBuilder;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.Mnemonic;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

public class PaintProject extends Application {
    File file = null;                           //file = whatever while is currently open
                                                      //initialized to a blank canvas
    //ResizableCanvas canvas = new ResizableCanvas(800,800);    
    Canvas canvas = new Canvas(800,800);        //New Canvas of an arbitrary size
    ColorPicker colorPicker = new ColorPicker(Color.BLACK);
    Boolean saved = true;
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        BorderPane border = new BorderPane();
        Group canvasGroup = new Group();
        canvasGroup.getChildren().add(canvas);
        GraphicsContext context = canvas.getGraphicsContext2D();
        ScrollPane scroller = new ScrollPane();
        Stack<WritableImage> undoStack = new Stack<WritableImage>();
        WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
        undoStack.push(wImage);
        Stack<WritableImage> redoStack = new Stack<WritableImage>();
        final Slider widthSlider = new Slider(1,15,3);
        final Slider opacitySlider = new Slider(0,1.0,1.0);
        
        final Label widthLabel = new Label("    Line Width: ");
        final Label widthValueLabel = new Label(String.format(" %.2f     ",widthSlider.getValue()));
        final Label opacityLabel = new Label(" Opactiy: ");
        final Label opacityValueLabel = new Label(String.format(" %.2f     ",opacitySlider.getValue()));
        scroller.setContent(canvasGroup);
        scroller.maxWidthProperty().bind(border.widthProperty());
        border.setRight(scroller);
        
        //Setting the Canvas as center early so it doesn't cover anything up
        border.setCenter(canvasGroup);
        
        ToggleGroup group = new ToggleGroup();
        RadioButton freeHandDraw = new RadioButton("Free Hand");
        freeHandDraw.setToggleGroup(group);
        freeHandDraw.setSelected(true);
        RadioButton lineDraw = new RadioButton("Line");
        lineDraw.setToggleGroup(group);
        RadioButton rectangleDraw = new RadioButton("Square/Rectangle");
        rectangleDraw.setToggleGroup(group);
        RadioButton ellipseDraw = new RadioButton("Circle/Ellipse");
        ellipseDraw.setToggleGroup(group);
        RadioButton colorGrabber = new RadioButton("Grab Color");
        colorGrabber.setToggleGroup(group);
        //Setting up the Menu Bar
        MenuBar menuBar = new MenuBar();
        Menu menuFile = new Menu("File");
        //Open
        MenuItem menuOpen = MenuItemBuilder.create()
                .text("Open")
                .accelerator(new KeyCodeCombination(KeyCode.O, KeyCombination.CONTROL_DOWN))
                .onAction(e-> {
                        try {
                            file = Menus.openFile(primaryStage, context, canvas, file, saved, undoStack, redoStack);
                            if(file==null){System.out.println("File null");}
                            } catch (IOException ex) {
                                Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
                            }
                    })
                .build();
        
        //Save
        MenuItem menuSave = MenuItemBuilder.create()
                .text("Save")
                .accelerator(new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN))
                .onAction(e-> {
                        try {
                            if(file==null){System.out.println("File null");}
                            Menus.saveFile(primaryStage, canvas, file);
                            saved = true;
                            } catch (IOException ex) {
                                Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
                            }
                    })
                .build();
        
        //SaveAs
        MenuItem menuSaveAs = MenuItemBuilder.create()
                .text("SaveAs")
                .accelerator(new KeyCodeCombination(KeyCode.F12, KeyCombination.CONTROL_ANY))
                .onAction(e-> {
                        try {
                            Menus.saveAsFile(primaryStage, canvas);
                            saved = true;
                            } catch (IOException ex) {
                                Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
                            }
                    })
                .build();
        
        //Exit
        MenuItem menuExit = new MenuItem("Exit");
        menuExit.setOnAction(e->{
            try {
                Menus.Exit(primaryStage, canvas, file, saved);
            } catch (IOException ex) {
                Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        primaryStage.setOnCloseRequest(e->{
            try {
                Menus.Exit(primaryStage, canvas, file, saved);
            } catch (IOException ex) {
                Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        //Adding Items to the File menu
        menuFile.getItems().addAll(menuOpen,menuSave,menuSaveAs,menuExit);
        Menu menuEdit = new Menu("Edit");
        MenuItem menuUndo = MenuItemBuilder.create()
                .text("Undo")
                .accelerator(new KeyCodeCombination(KeyCode.Z, KeyCombination.CONTROL_DOWN))
                .onAction(e-> Draw.undo(canvas, context, undoStack, redoStack))
                .build();
        MenuItem menuRedo = MenuItemBuilder.create()
                .text("Redo")
                .accelerator(new KeyCodeCombination(KeyCode.Y, KeyCombination.CONTROL_DOWN))
                .onAction(e-> Draw.redo(canvas, context, undoStack, redoStack))
                .build();

        menuEdit.getItems().addAll(menuUndo,menuRedo);
        Menu menuView = new Menu("View");
        MenuItem menuZoomIn = MenuItemBuilder.create()
                .text("Zoom IN")
                .accelerator(new KeyCodeCombination(KeyCode.EQUALS, KeyCombination.CONTROL_DOWN))
                .onAction(e->Draw.zoomIn(canvas))
                .build();

        MenuItem menuZoomOut = MenuItemBuilder.create()
                .text("Zoom OUT")
                .accelerator(new KeyCodeCombination(KeyCode.MINUS, KeyCombination.CONTROL_DOWN))
                .onAction(e->Draw.zoomOut(canvas))
                .build();
        menuView.getItems().addAll(menuZoomIn,menuZoomOut);
        Menu menuHelp = new Menu("Help");
        //Help>About
        MenuItem menuAbout = new MenuItem("About");
        Alert about = new Alert(AlertType.INFORMATION);
        about.setTitle("About");
        about.setHeaderText(null);
        about.setContentText("This is the meaning of Pain(t)\n");
        menuAbout.setOnAction(e->{
            about.showAndWait();
        });
        menuHelp.getItems().add(menuAbout);
        
        //Adding Menus to the Bar
        menuBar.getMenus().addAll(menuFile,menuEdit,menuView,menuHelp);
        menuBar.setMinHeight(32);//Configuring the Menubar
        menuBar.maxWidthProperty().bind(border.widthProperty());
        
        

        //We start to draw when the mouse is pressed!
        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, (MouseEvent event) -> {
            //Here's where we tell the program how to draw
            //First, configuring the color, opacity, and width of the tool
            Color fillColor = colorPicker.getValue().deriveColor(1, 1, 1, opacitySlider.getValue());
            context.setFill(fillColor);
            context.setStroke(fillColor);
            context.setLineWidth(widthSlider.getValue());
            //Then we tool at the ToggleGroup to see what we are drawing
            if(group.getSelectedToggle() == freeHandDraw){
                System.out.println("freehand");
                Draw.freeHand(canvas, context, colorPicker, undoStack); //See Draw class for drawing functions
                redoStack.removeAllElements(); //Clear out the redo stack whenever you make changes
                                               //For all cases except when using the 
            }                       
            if(group.getSelectedToggle() == lineDraw){
                System.out.println("line");
                Draw.lineDraw(canvas, context, colorPicker, undoStack);
                redoStack.removeAllElements();
            }
            if(group.getSelectedToggle() == rectangleDraw){
                System.out.println("rect");
                Draw.rectangleDraw(canvas, context, colorPicker, undoStack);
                redoStack.removeAllElements();
            }
            if(group.getSelectedToggle() == ellipseDraw){
                System.out.println("ellipse");
                Draw.ellipseDraw(canvas, context, colorPicker, undoStack);
                redoStack.removeAllElements();
            }
            if(group.getSelectedToggle()== colorGrabber){
                System.out.println("fgrabber");
                Draw.colorGrabber(canvas, context, colorPicker);
            }
            
            saved = false;
        });
        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, (MouseEvent event) -> {
            
        });
        //Configuring the Slider for ease of use
        widthSlider.setMajorTickUnit(1);
        widthSlider.setSnapToTicks(true);
        widthSlider.setShowTickMarks(true);
        widthSlider.setShowTickLabels(true);
        opacitySlider.setMajorTickUnit(1);
        opacitySlider.setSnapToTicks(true);
        opacitySlider.setShowTickMarks(true);
        opacitySlider.setShowTickLabels(true);
        //Moving the slider changes the width of the line
        widthSlider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            widthValueLabel.setText(" "+String.format("%.2f     ", new_val));
        });
        opacitySlider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            opacityValueLabel.setText(" "+String.format("%.2f     ", new_val));
        });
        //The ColorPicker and the Slider hang out on the same row
        HBox hbox = new HBox();
        hbox.getChildren().addAll(colorPicker,widthLabel,widthSlider,widthValueLabel, 
                opacityLabel,opacitySlider,opacityValueLabel,
                freeHandDraw, lineDraw, rectangleDraw, ellipseDraw, colorGrabber);
        border.setTop(hbox);
        
        //And the MenuBar sits on the top of that row
        VBox vbox = new VBox();
        vbox.getChildren().addAll(menuBar, hbox);
        border.setTop(vbox);//Adding it all to the BorderPane
        Scene scene = new Scene(border, canvas.getWidth(), canvas.getHeight());

        primaryStage.setTitle("Paint Project");
        primaryStage.setScene(scene);
        primaryStage.show();         
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
