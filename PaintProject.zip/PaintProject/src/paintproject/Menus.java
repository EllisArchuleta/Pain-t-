/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintproject;

import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Optional;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Insets;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

/**
 * Methods involving the MenuBar of the application and the MenuFiles within the MenuBar,
 * including open, save, exit, and about methods, and the construction of the MenuBar
 * @author Ellis Archuleta
 */
public class Menus {

    /**
     * Opens a selected image file through a FileChooser, displaying that image
     * on the canvas
     *
     * @param primaryStage Stage of the application
     * @param tab the current CanvasTab
     * @return the file that has been opened
     * @throws IOException if the file is invalid or not chosen
     */
    public static File openFile(Stage primaryStage, CanvasTab tab) throws IOException {
        Boolean confirm = true;

        final FileChooser fileChooser = new FileChooser();
        
        fileChooser.setTitle("Select an Image");
        if (tab.getSaved() == false) {
            Alert alert = new Alert(AlertType.CONFIRMATION, "Would you like to save your changes?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
            alert.setHeaderText(null);

            alert.showAndWait();
            if (alert.getResult() == ButtonType.YES) {
                saveFile(primaryStage, tab);
                tab.setSaved(true);
                confirm = true;
                System.out.println("Yes");
            } else if (alert.getResult() == ButtonType.NO) {
                confirm = true;
                System.out.println("No");
            } else if (alert.getResult() == ButtonType.CANCEL) {
                confirm = false;
                System.out.println("Cancel");
            };

        }

        if (confirm != false) {
            configureFileChooser(fileChooser);
            tab.setFile(fileChooser.showOpenDialog(primaryStage));
            if (tab.getFile() != null) {
                Image image = new Image(tab.getFile().toURI().toString());
                //Image is opened by clearing out the old canvas
                tab.getContext().clearRect(0, 0, tab.getCanvas().getWidth(), tab.getCanvas().getHeight());
                tab.getCanvas().setWidth(image.getWidth());
                tab.getCanvas().setHeight(image.getHeight());
                //And drawing the image on to it
                tab.getContext().drawImage(image, 0, 0, tab.getCanvas().getWidth(), tab.getCanvas().getHeight());
                WritableImage wImage = new WritableImage((int) tab.getCanvas().getWidth(), (int) tab.getCanvas().getHeight());
                tab.getCanvas().snapshot(null, wImage);
                tab.getUndoStack().removeAllElements();
                tab.getRedoStack().removeAllElements();
                tab.getUndoStack().push(wImage);
                tab.setSaved(true);
                tab.getCanvas().setScaleX(1);
                tab.getCanvas().setScaleY(1);
            }

        }
        if (tab.getFile() == null) {
            System.out.println("File null");
        }
        return tab.getFile();
    }

    /**
     * Saves the changes made to the canvas as an image file, overwriting the
     * current loaded file, or creating a new file to be saved to if there is
     * none
     *
     * @param primaryStage Stage of the application
     * @param tab the current CanvasTab
     * @throws IOException if the file is invalid or not chosen
     * @see #saveAsFile(Stage primaryStage, Canvas canvas)
     */
    public static void saveFile(Stage primaryStage, CanvasTab tab) throws IOException {
        if (tab.getFile() != null) {
            try {
                double tempScaleX = tab.getCanvas().getScaleX();
                double tempScaleY = tab.getCanvas().getScaleY();
                tab.getCanvas().setScaleX(1);
                tab.getCanvas().setScaleY(1);
                //The image is saved by creating a new WritableImage and copying the canvas onto it
                WritableImage wImage = new WritableImage((int) tab.getCanvas().getWidth(), (int) tab.getCanvas().getHeight());
                tab.getCanvas().snapshot(null, wImage);

                //Then we render that and save it to the loaded file
                RenderedImage renderedImage = SwingFXUtils.fromFXImage(wImage, null);
                ImageIO.write(renderedImage, "png", tab.getFile());
                tab.getCanvas().setScaleX(tempScaleX);
                tab.getCanvas().setScaleY(tempScaleY);
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        } else {//If a file hasn't been loaded yet, it'll redirect you to the SaveAs function
            try {
                System.out.println("No file, Saving As");
                saveAsFile(primaryStage, tab.getCanvas());
            } catch (IOException ex) {
                Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Saves the current canvas as an image file to a destination selected
     * through a FileChooser
     *
     * @param primaryStage Stage of the window
     * @param canvas the current Canvas
     * @throws IOException if the file is invalid or not chosen
     */
    public static void saveAsFile(Stage primaryStage, Canvas canvas) throws IOException {
        //Same principle as regular Save, except you decide the file location via a FileChooser
        FileChooser fileSaver = new FileChooser();
        fileSaver.setTitle("Save Image");
        configureFileChooser(fileSaver);
        File saveFile = fileSaver.showSaveDialog(primaryStage);
        if (saveFile != null) {
            try {
                //The image is saved by creating a new WritableImage and copying the canvas onto it\
                double tempScaleX = canvas.getScaleX();
                double tempScaleY = canvas.getScaleY();
                canvas.setScaleX(1);
                canvas.setScaleY(1);
                WritableImage wImage = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());
                canvas.snapshot(null, wImage);
                //Then rendered and saved to the selected file
                RenderedImage renderedImage = SwingFXUtils.fromFXImage(wImage, null);
                ImageIO.write(renderedImage, "png", saveFile);
                canvas.setScaleX(tempScaleX);
                canvas.setScaleY(tempScaleY);
            } catch (IOException ex) {
                Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    /**
     * Checks if all changes have been saved, and prompts the user to save if
     * not
     *
     * @param primaryStage Stage of the window
     * @param tab the current CanvasTab
     * @throws IOException if the file is invalid or not chosen
     */
    public static void Exit(Stage primaryStage, CanvasTab tab) throws IOException {
        if (tab.getSaved() == true) {
            Platform.exit();
        } else {
            Alert alert = new Alert(AlertType.CONFIRMATION, "If you exit now you will lose all unsaved changes. Would you like to save?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
            alert.setHeaderText(null);
            alert.showAndWait();

            if (alert.getResult() == ButtonType.YES) {
                saveFile(primaryStage, tab);
                Platform.exit();
            }
            if (alert.getResult() == ButtonType.NO) {
                Platform.exit();
            }
            if (alert.getResult() == ButtonType.CANCEL);
        }
    }

    /**
     * Makes sure the FileChooser only shows image files
     *
     * @param fileChooser the FileChooser with which the user will select a file
     */
    public static void configureFileChooser(final FileChooser fileChooser) {

        fileChooser.setInitialDirectory(
                new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.jpg", "*.jpeg", ""
                        + "*.jfif", "*.jpe", "*.png", "*.gif", "*.tif", "*.tiff",
                        "*.ico", "*.heic", "*.webp"),
                new FileChooser.ExtensionFilter("JPEG", "*.jpg", "*.jpeg", "*.jfif", "*.jpe"),
                new FileChooser.ExtensionFilter("PNG", "*.png"),
                new FileChooser.ExtensionFilter("GIF", "*.gif"),
                new FileChooser.ExtensionFilter("TIFF", "*.tif", "*.tiff"),
                new FileChooser.ExtensionFilter("ICO", "*.ico"),
                new FileChooser.ExtensionFilter("HEIC", "*.heic"),
                new FileChooser.ExtensionFilter("WEBP", "*.webp")
        );

    }

    /**
     * Opens a dialog prompt for the dimensions for resizing, then sends those
     * specifications to Draw.resize
     *
     * @param canvas the current canvas
     * @param context GraphicsContext of the canvas
     * @param undoStack Stack of changes made to the canvas
     * @see Draw#resize
     */
    public static void resize(Canvas canvas, GraphicsContext context, Stack<WritableImage> undoStack) {
        // Create the custom dialog.
        Dialog<Double[]> dialog = new Dialog<>();
        dialog.setTitle("Resize");

        // Set the button types.
        ButtonType resizeButtonType = new ButtonType("Resize", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(resizeButtonType, ButtonType.CANCEL);

        // Create the width and height labels and fields.
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));
        dialog.getDialogPane().setContent(grid);
        TextField widthField = new TextField();
        widthField.setPromptText("x");
        TextField heightField = new TextField();
        heightField.setPromptText("y");
        grid.add(new Label("Enter width:"), 0, 0);
        grid.add(widthField, 1, 0);
        grid.add(new Label("Enter height:"), 0, 1);
        grid.add(heightField, 1, 1);
        //Read the width and height only if you press the "resize" button
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == resizeButtonType) {
                Double[] newSize = {Double.parseDouble(widthField.getText()), Double.parseDouble(heightField.getText())};
                return newSize;
            }
            return null;
        });
        Optional<Double[]> newSize = dialog.showAndWait();
        double width = newSize.get()[0];
        double height = newSize.get()[1];
        //And send it to the Draw class to do the actual resizing
        Draw.resize(canvas, context, undoStack, width, height);
    }

    /**
     * Loads the about information, including the release notes of the project
     *
     * @throws FileNotFoundException if the ReadMe file is not present
     */
    public static void menuAbout() throws FileNotFoundException {
        Alert about = new Alert(AlertType.INFORMATION);
        about.setTitle("About");
        about.setHeaderText("This is the meaning of Pain(t)\n");
        String aboutText = "";
        //FileReader aboutReader = new FileReader("ReadMe.txt");
        try (BufferedReader aboutReader = new BufferedReader(new FileReader(new File("src\\ReadMe.txt")))) {

            String line;
            while ((line = aboutReader.readLine()) != null) {
                aboutText += (line + "\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        TextArea textArea = new TextArea(aboutText);
        textArea.setEditable(false);
        textArea.setWrapText(true);
        about.getDialogPane().setContent(textArea);
        about.setResizable(true);

        about.showAndWait();
    }

}
