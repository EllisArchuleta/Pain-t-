/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paintproject;

import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

/**
 *
 * @author micha
 */
public class Menus {
    public static File openFile(Stage primaryStage, GraphicsContext context, Canvas canvas, File file, Boolean saved, Stack<WritableImage> undoStack, Stack<WritableImage> redoStack) throws IOException{
        Boolean confirm = true;
        
        final FileChooser fileChooser = new FileChooser();
        File tempFile = file;
        fileChooser.setTitle("Select an Image");
        configureFileChooser(fileChooser);
        file = fileChooser.showOpenDialog(primaryStage);
        if(saved == false){
            Alert alert = new Alert(AlertType.CONFIRMATION, "Would you like to save your changes?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
            alert.setHeaderText(null);
            
            alert.showAndWait();
            if (alert.getResult() == ButtonType.YES) {
                saveFile(primaryStage, canvas, tempFile);
                saved = true;
                confirm = true;
                System.out.println("Yes");
            }
            else if (alert.getResult() == ButtonType.NO) {
                confirm = true;
                System.out.println("No");
            }
            else if (alert.getResult() == ButtonType.CANCEL){
                confirm = false;
                System.out.println("Cancel");
            };

        }
        //if(confirm!=true){System.out.println("Not Confirmed");}
        if(file!=null && confirm!=false){
            Image image = new Image(file.toURI().toString());
            //Image is opened by clearing out the old canvas
            context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            canvas.setWidth(image.getWidth());                  
            canvas.setHeight(image.getHeight());
            //And drawing the image on to it
            context.drawImage(image, 0, 0,canvas.getWidth(), canvas.getHeight());
            WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
            canvas.snapshot(null,wImage);
            undoStack.removeAllElements();
            redoStack.removeAllElements();
            undoStack.push(wImage);
            saved = true;
            canvas.setScaleX(1);
            canvas.setScaleY(1);
        }
        if(file==null){System.out.println("File null");}
        return file;
    }
    public static void saveFile(Stage primaryStage, Canvas canvas, File file) throws IOException{
        if (file != null) {
                try {
                    double tempScaleX = canvas.getScaleX();
                    double tempScaleY = canvas.getScaleY();
                    canvas.setScaleX(1);
                    canvas.setScaleY(1);
                    //The image is saved by creating a new WritableImage and copying the canvas onto it
                    WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
                    canvas.snapshot(null,wImage);
                    
                    //Then we render that and save it to the loaded file
                    RenderedImage renderedImage = SwingFXUtils.fromFXImage(wImage,null);
                    ImageIO.write(renderedImage,"png",file);
                    canvas.setScaleX(tempScaleX);
                    canvas.setScaleY(tempScaleY);
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            else{//If a file hasn't been loaded yet, it'll redirect you to the SaveAs function
                try {
                    System.out.println("No file, Saving As");
                    saveAsFile(primaryStage,canvas);
                } catch (IOException ex) {
                    Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    }
    public static void saveAsFile(Stage primaryStage, Canvas canvas) throws IOException{
        //Same principle as regular Save, except you decide the file location via a FileChooser
        FileChooser fileSaver = new FileChooser();
        fileSaver.setTitle("Save Image");
        configureFileChooser(fileSaver);
        File saveFile = fileSaver.showSaveDialog(primaryStage);
        if (saveFile != null) {
            try{
                //The image is saved by creating a new WritableImage and copying the canvas onto it\
                double tempScaleX = canvas.getScaleX();
                double tempScaleY = canvas.getScaleY();
                canvas.setScaleX(1);
                canvas.setScaleY(1);
                WritableImage wImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
                canvas.snapshot(null,wImage);
                //Then rendered and saved to the selected file
                RenderedImage renderedImage = SwingFXUtils.fromFXImage(wImage,null);
                ImageIO.write(renderedImage,"png",saveFile);
                canvas.setScaleX(tempScaleX);
                canvas.setScaleY(tempScaleY);
            }catch (IOException ex) {
                        Logger.getLogger(PaintProject.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    public static void Exit(Stage primaryStage, Canvas canvas, File file, Boolean saved) throws IOException{
        if(saved == true){
            Platform.exit();
        }
        else{
            Alert alert = new Alert(AlertType.CONFIRMATION, "If you exit now you will lose all unsaved changes. Would you like to save?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
            alert.setHeaderText(null);
            alert.showAndWait();

            if (alert.getResult() == ButtonType.YES) {
                saveFile(primaryStage, canvas, file);
                Platform.exit();
            }
            if (alert.getResult() == ButtonType.NO) {
                Platform.exit();
            }
            if (alert.getResult() == ButtonType.CANCEL);
        }
    }
    public static void configureFileChooser(final FileChooser fileChooser)
    {
        
        fileChooser.setInitialDirectory(
        new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("All Images", "*.jpg", "*.jpeg",""
                    + "*.jfif","*.jpe","*.png","*.gif","*.tif","*.tiff",
                    "*.ico","*.heic","*.webp"),
            new FileChooser.ExtensionFilter("JPEG", "*.jpg", "*.jpeg","*.jfif","*.jpe"),
            new FileChooser.ExtensionFilter("PNG","*.png"),
            new FileChooser.ExtensionFilter("GIF","*.gif"),
            new FileChooser.ExtensionFilter("TIFF","*.tif","*.tiff"),
            new FileChooser.ExtensionFilter("ICO","*.ico"),
            new FileChooser.ExtensionFilter("HEIC","*.heic"),
            new FileChooser.ExtensionFilter("WEBP","*.webp")
        );  
        
        
    }
}
